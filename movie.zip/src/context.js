import React, { useContext, useState } from 'react';
import useFetch from './useFetch';

const AppContext = React.createContext();

// we are getting the children and that is app component in our case
const AppProvider = ({ children }) => {
  const [query, setQuery] = useState('');
  const { isLoading, isError, movie } = useFetch(`&s=spider`);

  return <AppContext.Provider value={{ query, movie, setQuery, isLoading, isError }}>{children}</AppContext.Provider>;
};

const useGlobalContext = () => {
  return useContext(AppContext);
};

export { AppContext, AppProvider, useGlobalContext };
